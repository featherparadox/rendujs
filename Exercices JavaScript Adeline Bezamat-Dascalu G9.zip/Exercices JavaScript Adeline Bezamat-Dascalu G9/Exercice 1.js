function getElement(elt) {
    return document.querySelector(elt);
}
const myElement = getElement('#fr');
console.log(myElement);